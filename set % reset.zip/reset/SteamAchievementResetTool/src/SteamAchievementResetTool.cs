using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Web.Script.Serialization;
using System.Windows.Forms;

namespace SteamAchievementResetTool
{
    public sealed class Achievement
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public bool Unlocked { get; set; }
        public bool Readable { get; set; }
        public uint UnlockTime { get; set; }
    }

    public interface IBackend : IDisposable
    {
        uint AppId { get; }
        ulong AccountId { get; }
        string AccountName { get; }
        bool LoggedOn { get; }
        event Action<int> Received;
        event Action<int> Stored;
        bool Request();
        void Pump();
        List<Achievement> Read();
        bool Clear(string id);
        bool Store();
    }

    internal static class Native
    {
        private const string Dll = "steam_api64.dll";
        [StructLayout(LayoutKind.Sequential, Pack = 8)]
        internal struct Callback { public int User; public int Id; public IntPtr Data; public int Size; }
        [DllImport(Dll, CallingConvention = CallingConvention.Cdecl)] [return: MarshalAs(UnmanagedType.I1)] internal static extern bool SteamAPI_Init();
        [DllImport(Dll, CallingConvention = CallingConvention.Cdecl)] internal static extern void SteamAPI_Shutdown();
        [DllImport(Dll, CallingConvention = CallingConvention.Cdecl)] internal static extern int SteamAPI_GetHSteamPipe();
        [DllImport(Dll, CallingConvention = CallingConvention.Cdecl)] internal static extern void SteamAPI_ManualDispatch_Init();
        [DllImport(Dll, CallingConvention = CallingConvention.Cdecl)] internal static extern void SteamAPI_ManualDispatch_RunFrame(int pipe);
        [DllImport(Dll, CallingConvention = CallingConvention.Cdecl)] [return: MarshalAs(UnmanagedType.I1)] internal static extern bool SteamAPI_ManualDispatch_GetNextCallback(int pipe, out Callback message);
        [DllImport(Dll, CallingConvention = CallingConvention.Cdecl)] internal static extern void SteamAPI_ManualDispatch_FreeLastCallback(int pipe);
        [DllImport(Dll, CallingConvention = CallingConvention.Cdecl)] internal static extern IntPtr SteamAPI_SteamUserStats_v012();
        [DllImport(Dll, CallingConvention = CallingConvention.Cdecl)] internal static extern IntPtr SteamAPI_SteamUser_v021();
        [DllImport(Dll, CallingConvention = CallingConvention.Cdecl)] internal static extern IntPtr SteamAPI_SteamFriends_v017();
        [DllImport(Dll, CallingConvention = CallingConvention.Cdecl)] internal static extern IntPtr SteamAPI_SteamUtils_v010();
        [DllImport(Dll, CallingConvention = CallingConvention.Cdecl)] internal static extern IntPtr SteamAPI_SteamApps_v008();
        [DllImport(Dll, CallingConvention = CallingConvention.Cdecl)] internal static extern uint SteamAPI_ISteamUtils_GetAppID(IntPtr self);
        [DllImport(Dll, CallingConvention = CallingConvention.Cdecl)] [return: MarshalAs(UnmanagedType.I1)] internal static extern bool SteamAPI_ISteamApps_BIsSubscribedApp(IntPtr self, uint id);
        [DllImport(Dll, CallingConvention = CallingConvention.Cdecl)] internal static extern ulong SteamAPI_ISteamUser_GetSteamID(IntPtr self);
        [DllImport(Dll, CallingConvention = CallingConvention.Cdecl)] [return: MarshalAs(UnmanagedType.I1)] internal static extern bool SteamAPI_ISteamUser_BLoggedOn(IntPtr self);
        [DllImport(Dll, CallingConvention = CallingConvention.Cdecl)] internal static extern IntPtr SteamAPI_ISteamFriends_GetPersonaName(IntPtr self);
        [DllImport(Dll, CallingConvention = CallingConvention.Cdecl)] [return: MarshalAs(UnmanagedType.I1)] internal static extern bool SteamAPI_ISteamUserStats_RequestCurrentStats(IntPtr self);
        [DllImport(Dll, CallingConvention = CallingConvention.Cdecl)] internal static extern uint SteamAPI_ISteamUserStats_GetNumAchievements(IntPtr self);
        [DllImport(Dll, CallingConvention = CallingConvention.Cdecl)] internal static extern IntPtr SteamAPI_ISteamUserStats_GetAchievementName(IntPtr self, uint index);
        [DllImport(Dll, CallingConvention = CallingConvention.Cdecl)] internal static extern IntPtr SteamAPI_ISteamUserStats_GetAchievementDisplayAttribute(IntPtr self, byte[] name, byte[] key);
        [DllImport(Dll, CallingConvention = CallingConvention.Cdecl)] [return: MarshalAs(UnmanagedType.I1)] internal static extern bool SteamAPI_ISteamUserStats_GetAchievementAndUnlockTime(IntPtr self, byte[] name, [MarshalAs(UnmanagedType.I1)] out bool achieved, out uint time);
        [DllImport(Dll, CallingConvention = CallingConvention.Cdecl)] [return: MarshalAs(UnmanagedType.I1)] internal static extern bool SteamAPI_ISteamUserStats_ClearAchievement(IntPtr self, byte[] name);
        [DllImport(Dll, CallingConvention = CallingConvention.Cdecl)] [return: MarshalAs(UnmanagedType.I1)] internal static extern bool SteamAPI_ISteamUserStats_StoreStats(IntPtr self);
        internal static byte[] Utf8(string value) { return Encoding.UTF8.GetBytes(value + "\0"); }
        internal static bool TryReadStatsCallback(Callback message, uint app, ulong account, out int result)
        {
            result = 0;
            if ((message.Id != 1101 && message.Id != 1102) || message.Data == IntPtr.Zero || message.Size < 12) return false;
            if (unchecked((ulong)Marshal.ReadInt64(message.Data)) != app) return false;
            // CSteamID is nested with 4-byte alignment: UserStatsReceived_t's
            // account field starts at 12, even though the Win64 callback size is 24.
            if (message.Id == 1101 && (message.Size < 20 || unchecked((ulong)Marshal.ReadInt64(message.Data, 12)) != account)) return false;
            result = Marshal.ReadInt32(message.Data, 8); return true;
        }
        internal static string Text(IntPtr pointer)
        {
            if (pointer == IntPtr.Zero) return "";
            int length = 0;
            while (length < 65536 && Marshal.ReadByte(pointer, length) != 0) length++;
            if (length == 65536) throw new InvalidDataException("Steam 返回了无效文本。");
            byte[] bytes = new byte[length]; Marshal.Copy(pointer, bytes, 0, length);
            return Encoding.UTF8.GetString(bytes);
        }
    }

    public sealed class SteamBackend : IBackend
    {
        private IntPtr stats, user;
        private int pipe;
        private bool active;
        public List<string> Diagnostics = new List<string>();
        public uint AppId { get; private set; }
        public ulong AccountId { get { return Native.SteamAPI_ISteamUser_GetSteamID(user); } }
        public string AccountName { get { return Native.Text(Native.SteamAPI_ISteamFriends_GetPersonaName(Native.SteamAPI_SteamFriends_v017())); } }
        public bool LoggedOn { get { return active && Native.SteamAPI_ISteamUser_BLoggedOn(user); } }
        public event Action<int> Received;
        public event Action<int> Stored;
        public SteamBackend(uint appId)
        {
            Environment.SetEnvironmentVariable("SteamAppId", appId.ToString());
            Environment.SetEnvironmentVariable("SteamGameId", appId.ToString());
            if (!Native.SteamAPI_Init()) throw new InvalidOperationException("无法连接 Steam。请先启动并登录 Steam，确认 App ID 正确且当前账号拥有该游戏，再重开工具。");
            active = true;
            try
            {
                AppId = Native.SteamAPI_ISteamUtils_GetAppID(Native.SteamAPI_SteamUtils_v010());
                if (AppId != appId) throw new InvalidOperationException("Steam 连接到了其他 App ID，请重开工具。");
                if (!Native.SteamAPI_ISteamApps_BIsSubscribedApp(Native.SteamAPI_SteamApps_v008(), appId)) throw new InvalidOperationException("当前 Steam 账号未提供该游戏的有效使用许可。");
                stats = Native.SteamAPI_SteamUserStats_v012(); user = Native.SteamAPI_SteamUser_v021();
                if (stats == IntPtr.Zero || user == IntPtr.Zero) throw new InvalidOperationException("Steam 成就接口不可用。");
                pipe = Native.SteamAPI_GetHSteamPipe(); Native.SteamAPI_ManualDispatch_Init();
            }
            catch { Dispose(); throw; }
        }
        public bool Request() { return Native.SteamAPI_ISteamUserStats_RequestCurrentStats(stats); }
        public void Pump()
        {
            Native.SteamAPI_ManualDispatch_RunFrame(pipe);
            Native.Callback message;
            var events = new List<KeyValuePair<int, int>>();
            while (Native.SteamAPI_ManualDispatch_GetNextCallback(pipe, out message))
            {
                try
                {
                    if (Diagnostics.Count < 80) Diagnostics.Add("callback=" + message.Id + ", size=" + message.Size);
                    int result;
                    if (Native.TryReadStatsCallback(message, AppId, AccountId, out result)) events.Add(new KeyValuePair<int, int>(message.Id, result));
                }
                finally { Native.SteamAPI_ManualDispatch_FreeLastCallback(pipe); }
            }
            foreach (var item in events)
            {
                if (item.Key == 1101 && Received != null) Received(item.Value);
                if (item.Key == 1102 && Stored != null) Stored(item.Value);
            }
        }
        public List<Achievement> Read()
        {
            uint count = Native.SteamAPI_ISteamUserStats_GetNumAchievements(stats);
            if (count > 100000) throw new InvalidDataException("Steam 返回的成就数量异常。");
            var result = new List<Achievement>();
            for (uint i = 0; i < count; i++)
            {
                string id = Native.Text(Native.SteamAPI_ISteamUserStats_GetAchievementName(stats, i));
                if (String.IsNullOrEmpty(id)) throw new InvalidDataException("Steam 返回了空成就 ID，请重新读取。");
                bool achieved; uint time; byte[] bytes = Native.Utf8(id);
                bool readable = Native.SteamAPI_ISteamUserStats_GetAchievementAndUnlockTime(stats, bytes, out achieved, out time);
                result.Add(new Achievement { Id = id, Name = Native.Text(Native.SteamAPI_ISteamUserStats_GetAchievementDisplayAttribute(stats, bytes, Native.Utf8("name"))), Description = Native.Text(Native.SteamAPI_ISteamUserStats_GetAchievementDisplayAttribute(stats, bytes, Native.Utf8("desc"))), Unlocked = achieved, Readable = readable, UnlockTime = time });
            }
            return result;
        }
        public bool Clear(string id) { return Native.SteamAPI_ISteamUserStats_ClearAchievement(stats, Native.Utf8(id)); }
        public bool Store() { return Native.SteamAPI_ISteamUserStats_StoreStats(stats); }
        public void Dispose() { if (active) { active = false; Native.SteamAPI_Shutdown(); } }
    }

    public sealed class Session : IDisposable
    {
        private readonly IBackend backend;
        private readonly Action<List<Achievement>> backup;
        private readonly ulong account;
        private readonly uint app;
        private DateTime deadline;
        private List<string> accepted = new List<string>();
        private List<string> rejected = new List<string>();
        public string State { get; private set; }
        public List<Achievement> Items { get; private set; }
        public event Action Changed;
        public event Action<string> Message;
        public bool Ready { get { return State == "ready"; } }
        public bool Busy { get { return State == "loading" || State == "storing" || State == "verifying"; } }
        public Session(IBackend backend, Action<List<Achievement>> backup)
        {
            this.backend = backend; this.backup = backup; account = backend.AccountId; app = backend.AppId;
            State = "idle"; Items = new List<Achievement>(); backend.Received += Received; backend.Stored += Stored;
        }
        private void Notify() { if (Changed != null) Changed(); }
        private void Say(string text) { if (Message != null) Message(text); }
        private void CheckIdentity()
        {
            if (!backend.LoggedOn || backend.AccountId != account || backend.AppId != app) throw new InvalidOperationException("Steam 账号或登录状态已改变，请关闭工具后重新连接。");
        }
        public void Refresh()
        {
            if (Busy) return;
            try
            {
                CheckIdentity(); State = "loading"; deadline = DateTime.UtcNow.AddSeconds(40); Notify();
                if (!backend.Request()) Fail("Steam 未接受读取请求，请检查登录与网络状态。");
            }
            catch (Exception ex) { Fail(ex.Message); }
        }
        public void Tick()
        {
            try
            {
                backend.Pump();
                if (Busy && DateTime.UtcNow > deadline) Fail(State == "loading" ? "读取超时。请确认 App ID 和网络状态，然后重新读取。" : "保存结果尚未确认。Steam 可能稍后同步，请重新读取或在 Steam 中核对。");
            }
            catch (Exception ex) { Fail(ex.Message); }
        }
        private void Received(int result)
        {
            if (State != "loading" && State != "verifying") return;
            if (result != 1) { Fail("Steam 读取失败：" + ResultText(result)); return; }
            bool verifying = State == "verifying";
            CheckIdentity(); Items = backend.Read(); State = "ready"; Notify();
            if (verifying)
            {
                var locked = new HashSet<string>(Items.Where(x => x.Readable && !x.Unlocked).Select(x => x.Id));
                int confirmed = accepted.Count(x => locked.Contains(x));
                Say("Steam 已确认保存。本次确认清除 " + confirmed + " 项；被拒绝 " + rejected.Count + " 项；未确认 " + (accepted.Count - confirmed) + " 项。");
                if (rejected.Count > 0) Say("被拒绝的成就 ID：" + String.Join(", ", rejected));
            }
            else Say("读取完成：共 " + Items.Count + " 项，已解锁 " + Items.Count(x => x.Readable && x.Unlocked) + " 项。" + (Items.Count == 0 ? "该 App ID 可能没有公开成就。" : ""));
        }
        public void ClearAchievements(IEnumerable<string> requested)
        {
            if (!Ready) return;
            try
            {
                CheckIdentity();
                // Re-read cached flags before clearing only readable, unlocked achievements.
                Items = backend.Read();
                var ids = new HashSet<string>(requested);
                var available = new HashSet<string>(Items.Select(x => x.Id));
                if (ids.Any(x => !available.Contains(x))) throw new InvalidOperationException("成就列表已变化，请重新读取。");
                var targets = Items.Where(x => ids.Contains(x.Id) && x.Readable && x.Unlocked).ToList();
                if (targets.Count == 0) { Say("没有可清除的已解锁成就。"); Notify(); return; }
                backup(Items); // A failed snapshot prevents any ClearAchievement call.
                CheckIdentity(); accepted.Clear(); rejected.Clear();
                State = "storing"; deadline = DateTime.UtcNow.AddSeconds(45); Notify();
                foreach (var item in targets) { if (backend.Clear(item.Id)) accepted.Add(item.Id); else rejected.Add(item.Id); }
                if (accepted.Count == 0) { State = "ready"; Notify(); Say("Steam 拒绝了全部 " + rejected.Count + " 项修改：" + String.Join(", ", rejected)); return; }
                if (!backend.Store()) { Fail("Steam 未接受保存请求，尚未确认结果。修改可能稍后同步，请重新读取核对。"); return; }
                Say("已提交 " + accepted.Count + " 项，正在等待 Steam 保存确认……");
            }
            catch (Exception ex) { Fail(ex.Message); }
        }
        private void Stored(int result)
        {
            if (State != "storing") return;
            if (result != 1) { Fail("Steam 保存未确认：" + ResultText(result) + "。请重新读取核对状态。"); return; }
            State = "verifying"; deadline = DateTime.UtcNow.AddSeconds(40); Notify();
            if (!backend.Request()) Fail("Steam 已返回保存成功，但再次读取失败；请刷新成就列表核对。");
        }
        private void Fail(string text) { State = "error"; Notify(); Say(text); }
        public static string ResultText(int code)
        {
            switch (code) { case 2: return "一般错误 (2)"; case 3: return "无法连接 (3)"; case 8: return "数据被拒绝或已过期 (8)"; case 15: return "没有权限 (15)"; case 16: return "超时 (16)"; case 21: return "未登录 (21)"; case 25: return "达到限制 (25)"; default: return "错误码 " + code; }
        }
        public void Dispose() { backend.Dispose(); }
    }

    internal sealed class MainForm : Form
    {
        private readonly TextBox appBox = new TextBox();
        private readonly Button load = new Button();
        private readonly Button all = new Button();
        private readonly Button selected = new Button();
        private readonly Label identity = new Label();
        private readonly Label status = new Label();
        private readonly ListView list = new ListView();
        private readonly TextBox log = new TextBox();
        private readonly System.Windows.Forms.Timer timer = new System.Windows.Forms.Timer();
        private Session session;
        private SteamBackend backend;
        private uint connectedApp;
        private bool attempted;
        private readonly uint initialApp;
        internal MainForm(uint initialApp)
        {
            this.initialApp = initialApp;
            Text = "Steam 单机成就清除工具"; MinimumSize = new Size(860, 620); Size = new Size(1060, 740);
            StartPosition = FormStartPosition.CenterScreen; Font = new Font("Microsoft YaHei UI", 10F);
            BackColor = Color.FromArgb(246, 248, 251);
            var layout = new TableLayoutPanel { Dock = DockStyle.Fill, Padding = new Padding(22), ColumnCount = 1, RowCount = 7 };
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 43)); layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 42));
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 42)); layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 32));
            layout.RowStyles.Add(new RowStyle(SizeType.Percent, 100)); layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 52)); layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 112));
            Controls.Add(layout);
            layout.Controls.Add(new Label { Text = "Steam 单机成就清除工具", Font = new Font(Font.FontFamily, 19, FontStyle.Bold), AutoSize = true }, 0, 0);
            var top = new FlowLayoutPanel { Dock = DockStyle.Fill, WrapContents = false };
            top.Controls.Add(new Label { Text = "游戏 App ID", AutoSize = true, Margin = new Padding(0, 7, 12, 0) });
            appBox.Text = (initialApp == 0 ? 4186640u : initialApp).ToString(); appBox.Width = 170; top.Controls.Add(appBox);
            load.Text = "连接并读取"; load.AutoSize = true; load.Click += delegate { Connect(); }; top.Controls.Add(load);
            top.Controls.Add(new Label { Text = "商店链接 /app/ 后的数字", AutoSize = true, ForeColor = Color.DimGray, Margin = new Padding(14, 7, 0, 0) });
            layout.Controls.Add(top, 0, 1);
            identity.Text = "请先登录 Steam，再输入你拥有的游戏 App ID。"; identity.Dock = DockStyle.Fill; layout.Controls.Add(identity, 0, 2);
            status.Text = "点击清除会将成就恢复为未解锁状态，保留游戏统计数值。"; status.Dock = DockStyle.Fill; status.ForeColor = Color.FromArgb(62, 84, 112); layout.Controls.Add(status, 0, 3);
            list.Dock = DockStyle.Fill; list.View = View.Details; list.CheckBoxes = true; list.FullRowSelect = true; list.GridLines = false; list.HideSelection = false;
            list.Columns.Add("状态", 90); list.Columns.Add("成就名称", 225); list.Columns.Add("说明", 400); list.Columns.Add("成就 ID", 190);
            layout.Controls.Add(list, 0, 4);
            var actions = new FlowLayoutPanel { Dock = DockStyle.Fill, Padding = new Padding(0, 10, 0, 0) };
            all.Text = "一键清除全部"; all.AutoSize = true; all.BackColor = Color.FromArgb(32, 96, 172); all.ForeColor = Color.White; all.FlatStyle = FlatStyle.Flat; all.Enabled = false;
            selected.Text = "清除勾选项"; selected.AutoSize = true; selected.Enabled = false;
            all.Click += delegate { if (session != null) session.ClearAchievements(session.Items.Select(x => x.Id).ToArray()); };
            selected.Click += delegate { if (session != null) session.ClearAchievements(list.CheckedItems.Cast<ListViewItem>().Select(x => (string)x.Tag).ToArray()); };
            actions.Controls.Add(all); actions.Controls.Add(selected); layout.Controls.Add(actions, 0, 5);
            log.Multiline = true; log.ReadOnly = true; log.ScrollBars = ScrollBars.Vertical; log.Dock = DockStyle.Fill; log.BackColor = Color.White; layout.Controls.Add(log, 0, 6);
            timer.Interval = 100; timer.Tick += delegate { if (session != null) session.Tick(); }; timer.Start();
            FormClosing += delegate(object sender, FormClosingEventArgs e) { if (session != null && session.Busy) { e.Cancel = true; Append("当前操作仍在等待 Steam 返回，请等待完成或超时后关闭。"); } };
            FormClosed += delegate { timer.Stop(); if (session != null) session.Dispose(); };
            Shown += delegate { if (initialApp != 0) Connect(); };
        }
        private void Connect()
        {
            uint app;
            if (!UInt32.TryParse(appBox.Text.Trim(), out app) || app == 0 || app > 0xFFFFFF) { Append("请输入有效的数字 App ID。"); return; }
            if (session != null && session.Busy) return;
            if (attempted && (session == null || app != connectedApp))
            {
                // A fresh process prevents Steam's cached application context leaking across games.
                Process.Start(new ProcessStartInfo(Application.ExecutablePath, "--app " + app) { WorkingDirectory = AppDomain.CurrentDomain.BaseDirectory }); Close(); return;
            }
            if (session != null) { session.Refresh(); return; }
            attempted = true;
            try
            {
                backend = new SteamBackend(app); connectedApp = app;
                identity.Text = "目标 App ID：" + app + "    当前账号：" + backend.AccountName + "    Steam ID：" + backend.AccountId;
                session = new Session(backend, delegate(List<Achievement> items)
                {
                    string path = Program.WriteSnapshot(app, backend.AccountId, backend.AccountName, items);
                    Append("已保存操作前记录：" + path);
                });
                session.Changed += UpdateView; session.Message += Append; session.Refresh();
            }
            catch (Exception ex) { Append("连接失败：" + ex.Message); }
        }
        private void UpdateView()
        {
            load.Enabled = !session.Busy; appBox.Enabled = !session.Busy;
            all.Enabled = session.Ready && session.Items.Any(x => x.Readable && x.Unlocked); selected.Enabled = all.Enabled;
            if (session.State == "loading") status.Text = "正在读取成就……";
            else if (session.State == "storing") status.Text = "正在等待 Steam 保存确认……";
            else if (session.State == "verifying") status.Text = "保存已获确认，正在重新读取……";
            else if (session.State == "error") status.Text = "操作未确认完成，请查看下方提示。";
            else status.Text = "共 " + session.Items.Count + " 项；已解锁 " + session.Items.Count(x => x.Readable && x.Unlocked) + " 项。点击清除即提交，恢复为未解锁状态。";
            if (!session.Ready) return;
            var checkedIds = new HashSet<string>(list.CheckedItems.Cast<ListViewItem>().Select(x => (string)x.Tag));
            list.BeginUpdate(); list.Items.Clear();
            foreach (var item in session.Items)
            {
                var row = new ListViewItem(!item.Readable ? "读取失败" : item.Unlocked ? "已解锁" : "未解锁");
                row.SubItems.Add(String.IsNullOrEmpty(item.Name) ? item.Id : item.Name); row.SubItems.Add(item.Description); row.SubItems.Add(item.Id);
                row.Tag = item.Id; row.Checked = checkedIds.Contains(item.Id); if (!item.Readable || !item.Unlocked) row.ForeColor = Color.Gray; list.Items.Add(row);
            }
            list.EndUpdate();
        }
        private void Append(string text) { log.AppendText(DateTime.Now.ToString("HH:mm:ss") + "  " + text + Environment.NewLine); }
    }

    internal static class Program
    {
        internal static string WriteSnapshot(uint app, ulong account, string name, List<Achievement> items)
        {
            string folder = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "records"); Directory.CreateDirectory(folder);
            string path = Path.Combine(folder, app + "_" + account + "_" + DateTime.UtcNow.ToString("yyyyMMdd_HHmmss_fff") + ".json");
            File.WriteAllText(path, Json(new { AppId = app, SteamId = account.ToString(), AccountName = name, TimeUtc = DateTime.UtcNow.ToString("o"), Achievements = items }), new UTF8Encoding(false)); return path;
        }
        internal static string Json(object obj) { return new JavaScriptSerializer { MaxJsonLength = Int32.MaxValue }.Serialize(obj); }
        [STAThread]
        private static int Main(string[] args)
        {
            try
            {
                if (args.Length >= 3 && args[0] == "--probe") return Probe(UInt32.Parse(args[1]), Path.GetFullPath(args[2]));
                if (args.Length >= 2 && args[0] == "--self-test") { Tests.Run(); File.WriteAllText(args[1], "PASS: all session tests passed; no native API writes.\r\n"); return 0; }
                if (args.Length == 2 && args[0] == "--preview")
                {
                    Application.EnableVisualStyles(); Application.SetCompatibleTextRenderingDefault(false);
                    using (var form = new MainForm(0))
                    {
                        form.ShowInTaskbar = false; form.Opacity = 0; form.Show(); Application.DoEvents(); form.PerformLayout();
                        using (var bitmap = new Bitmap(form.Width, form.Height)) { form.DrawToBitmap(bitmap, new Rectangle(Point.Empty, form.Size)); bitmap.Save(args[1], System.Drawing.Imaging.ImageFormat.Png); }
                        form.Close();
                    }
                    return 0;
                }
                uint app = args.Length == 2 && args[0] == "--app" ? UInt32.Parse(args[1]) : 0;
                Application.EnableVisualStyles(); Application.SetCompatibleTextRenderingDefault(false); Application.Run(new MainForm(app)); return 0;
            }
            catch (Exception ex)
            {
                if (args.Length >= 3 && args[0] == "--probe") File.WriteAllText(args[2], Json(new { Ok = false, Error = ex.ToString() }), new UTF8Encoding(false));
                else if (args.Length >= 2 && args[0] == "--self-test") File.WriteAllText(args[1], ex.ToString());
                else MessageBox.Show(ex.Message, "Steam 成就清除工具", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return 1;
            }
        }
        private static int Probe(uint app, string output)
        {
            using (var backend = new SteamBackend(app))
            using (var session = new Session(backend, delegate { throw new InvalidOperationException("Read-only probe cannot write achievements."); }))
            {
                string last = ""; session.Message += delegate(string text) { last = text; };
                session.Refresh();
                while (session.Busy) { session.Tick(); Thread.Sleep(50); }
                var cached = backend.Read();
                File.WriteAllText(output, Json(new { Ok = session.Ready, AppId = backend.AppId, SteamId = backend.AccountId.ToString(), AccountName = backend.AccountName, Message = last, Achievements = session.Items, ReadOnly = true, CachedCount = cached.Count, CachedReadableCount = cached.Count(x => x.Readable), Diagnostics = backend.Diagnostics }), new UTF8Encoding(false));
                return session.Ready ? 0 : 2;
            }
        }
    }
}
