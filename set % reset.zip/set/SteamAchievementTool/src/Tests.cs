using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;

namespace SteamAchievementTool
{
    internal sealed class FakeBackend : IBackend
    {
        public uint AppId { get; set; }
        public ulong AccountId { get; set; }
        public string AccountName { get { return "Test account"; } }
        public bool LoggedOn { get; set; }
        public event Action<int> Received;
        public event Action<int> Stored;
        public List<Achievement> Data = new List<Achievement>();
        public List<string> SetCalls = new List<string>();
        public HashSet<string> Reject = new HashSet<string>();
        public int StoreCalls;
        public bool StoreAccepted = true;
        public FakeBackend()
        {
            AppId = 42; AccountId = 123; LoggedOn = true;
            Data.Add(new Achievement { Id = "old", Readable = true, Unlocked = true });
            Data.Add(new Achievement { Id = "a", Readable = true });
            Data.Add(new Achievement { Id = "b", Readable = true });
            Data.Add(new Achievement { Id = "unreadable", Readable = false });
        }
        public bool Request() { return LoggedOn; }
        public void Pump() { }
        public List<Achievement> Read() { return Data.Select(x => new Achievement { Id = x.Id, Name = x.Name, Readable = x.Readable, Unlocked = x.Unlocked }).ToList(); }
        public bool Set(string id) { SetCalls.Add(id); if (Reject.Contains(id)) return false; Data.Single(x => x.Id == id).Unlocked = true; return true; }
        public bool Store() { StoreCalls++; return StoreAccepted; }
        public void Receive(int result) { if (Received != null) Received(result); }
        public void StoreResult(int result) { if (Stored != null) Stored(result); }
        public void Dispose() { }
    }
    internal static class Tests
    {
        private static void Check(bool value, string message) { if (!value) throw new Exception("TEST FAILURE: " + message); }
        private static Session Ready(FakeBackend b, Action<List<Achievement>> backup)
        {
            var s = new Session(b, backup); s.Refresh(); b.Receive(1); Check(s.Ready, "initial read"); return s;
        }
        public static void Run()
        {
            IntPtr memory = Marshal.AllocHGlobal(24);
            try
            {
                for (int i = 0; i < 24; i++) Marshal.WriteByte(memory, i, 0);
                Marshal.WriteInt64(memory, 0, 42); Marshal.WriteInt32(memory, 8, 1); Marshal.WriteInt64(memory, 12, 76561198000000123L);
                var callback = new Native.Callback { Id = 1101, Data = memory, Size = 24 }; int result;
                Check(Native.TryReadStatsCallback(callback, 42, 76561198000000123UL, out result) && result == 1, "Win64 callback account is at offset 12");
                Check(!Native.TryReadStatsCallback(callback, 42, 999, out result), "ignore another account's callback");
                Check(!Native.TryReadStatsCallback(callback, 43, 76561198000000123UL, out result), "ignore another game's callback");
                callback.Size = 16; Check(!Native.TryReadStatsCallback(callback, 42, 76561198000000123UL, out result), "reject truncated received callback");
                callback.Id = 1102; Check(Native.TryReadStatsCallback(callback, 42, 76561198000000123UL, out result), "decode stored callback");
            }
            finally { Marshal.FreeHGlobal(memory); }
            var b = new FakeBackend(); int backups = 0;
            var s = new Session(b, delegate { backups++; });
            s.Unlock(new[] { "a" }); Check(b.SetCalls.Count == 0, "cannot write before successful read");
            s.Refresh(); Check(b.SetCalls.Count == 0 && b.StoreCalls == 0, "refresh is read-only");
            b.Receive(1); Check(s.Ready && b.SetCalls.Count == 0, "read callback is read-only");
            var messages = new List<string>(); s.Message += messages.Add;
            s.Unlock(new[] { "a", "a", "old", "unreadable", "b" });
            Check(backups == 1 && b.SetCalls.SequenceEqual(new[] { "a", "b" }), "skip complete, unreadable and duplicate IDs");
            Check(b.StoreCalls == 1 && s.State == "storing", "one save per batch");
            Check(!messages.Any(x => x.Contains("已确认保存")), "no premature save-success message");
            s.Unlock(new[] { "a" }); Check(b.StoreCalls == 1, "ignore writes during active save");
            b.StoreResult(1); Check(s.State == "verifying", "wait for a fresh read after acknowledgement");
            b.Receive(1); Check(s.Ready && messages.Any(x => x.Contains("确认解锁 2 项")), "confirmed success after readback");
            s.Unlock(new[] { "a", "b" }); Check(b.StoreCalls == 1, "already-unlocked batch does not save");

            b = new FakeBackend(); s = Ready(b, delegate { throw new Exception("disk full"); });
            s.Unlock(new[] { "a" }); Check(s.State == "error" && b.SetCalls.Count == 0, "snapshot failure prevents mutation");
            b = new FakeBackend(); s = Ready(b, delegate { }); b.AccountId = 999;
            s.Unlock(new[] { "a" }); Check(b.SetCalls.Count == 0, "account switch prevents mutation");
            b = new FakeBackend(); s = Ready(b, delegate { }); b.LoggedOn = false;
            s.Unlock(new[] { "a" }); Check(b.SetCalls.Count == 0, "disconnected account prevents mutation");
            b = new FakeBackend(); s = Ready(b, delegate { });
            s.Unlock(new[] { "wrong-game-id" }); Check(b.SetCalls.Count == 0, "unknown achievement cannot be submitted");
            b = new FakeBackend(); b.Reject.Add("a"); s = Ready(b, delegate { });
            s.Unlock(new[] { "a" }); Check(b.StoreCalls == 0 && s.Ready, "fully rejected batch does not save");
            b = new FakeBackend(); b.Reject.Add("b"); s = Ready(b, delegate { }); messages = new List<string>(); s.Message += messages.Add;
            s.Unlock(new[] { "a", "b" }); b.StoreResult(1); b.Receive(1);
            Check(messages.Any(x => x.Contains("确认解锁 1 项；被拒绝 1 项")), "partial failure reported accurately");
            b = new FakeBackend(); s = Ready(b, delegate { }); messages = new List<string>(); s.Message += messages.Add;
            s.Unlock(new[] { "a" }); b.StoreResult(8);
            Check(s.State == "error" && !messages.Any(x => x.Contains("已确认保存")), "server rejection is never success");
            b = new FakeBackend(); b.StoreAccepted = false; s = Ready(b, delegate { });
            s.Unlock(new[] { "a" }); Check(s.State == "error", "failed submission is unconfirmed");
        }
    }
}
